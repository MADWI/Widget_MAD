package com.mad.planchanges;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

public class PlanChangesActivity extends Activity{
	
	private final ParsePlanChanges pars = new ParsePlanChanges(10000);
	private ArrayList<DataPlanChanges> news= new ArrayList<DataPlanChanges>();
	private ListViewAdapterPlanChanges adapter;
	private ListView lvPlanChanges; 
	boolean enableExecuteRefresh = true;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		if(isOnline())
		{
			refreshMessages();
		}
		//else TOAST		
	}
	private Boolean refreshMessages()
	{
		if(isOnline())
		{
			//TOAST
			enableExecuteRefresh = false;
			ArrayList<DataPlanChanges> tempArray= null;
			tempArray = pars.getServerMessages();
			if(tempArray != null)
			{
				news = tempArray;	
				refreshListView();
				//TOAST
				enableExecuteRefresh = true;
				return true;
			}
		}
		else
			//TOAST
			return false;
		
		enableExecuteRefresh = true;
		return false;
	}
	
	private void refreshListView()
	{
		lvPlanChanges = (ListView)findViewById(R.id.listPlanChanges);
		adapter = new ListViewAdapterPlanChanges(getApplicationContext(),
			android.R.layout.simple_list_item_1,android.R.id.text1,news);
		lvPlanChanges.setAdapter(adapter);
		adapter.notifyDataSetChanged();
	}
	
	private Boolean isOnline()
	{
		ConnectivityManager m = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		
		return m.getActiveNetworkInfo().isConnectedOrConnecting();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.refresh:
			
			if (enableExecuteRefresh)
				refreshMessages();
			return true;
			case R.id.exit:
			this.finish();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}
}
